---
loai: gioi-thieu-ban-than
ho_va_ten: ""
dien_thoai: ""
email: ""
blog: ""
trang_about: ""
lead_page: ""
sale_page: ""
# --- Mạng xã hội (điền cái nào có, để trống cái không có) ---
youtube: ""
facebook_page: ""        # Fanpage / Trang
facebook_ca_nhan: ""     # FB cá nhân
tiktok: ""
instagram: ""
x: ""                    # Twitter/X
mang_xa_hoi_khac: ""     # LinkedIn, Threads, Zalo... nếu có
---

# Về tôi — [Họ và tên]

<!-- Bài About đầy đủ. Viết dạng CÂU CHUYỆN, không chỉ liệt kê. Điền theo gợi ý dưới, xoá phần gợi ý khi viết xong. Càng nhiều chi tiết thật, càng chạm — người đọc tin người, không tin chức danh. -->

**1. Tôi là ai, làm gì**
- Tên, nghề, vai trò hiện tại:
- Tôi giúp được ai điều gì (một câu rõ ràng):

**2. Câu chuyện cuộc đời**
- Xuất thân, tuổi thơ, nơi lớn lên:
- Bước ngoặt / biến cố thay đổi cuộc đời tôi:
- Tôi đã vượt qua điều gì để trở thành người hôm nay:

**3. Gia đình**
- Gia đình của tôi (bố mẹ, vợ/chồng, con cái…):
- Gia đình ảnh hưởng thế nào đến con người & lựa chọn của tôi:
- Điều tôi trân trọng / lý do tôi làm việc chăm chỉ:

**4. Hành trình kinh doanh / sự nghiệp**
- Tôi khởi nghiệp / vào nghề thế nào, vì sao:
- Thất bại & bài học lớn nhất:
- Thành tựu, cột mốc, con số đáng tự hào:
- Lý do tôi làm nghề này (sứ mệnh, động lực sâu xa):

**5. Các lĩnh vực khác của tôi**
- Đam mê / sở thích / thể thao / nghệ thuật:
- Giá trị sống, triết lý, điều tôi tin:
- Hoạt động cộng đồng, thiện nguyện, sở thích đặc biệt:
- Điều thú vị ít ai biết về tôi:

**6. Kết nối với bạn đọc**
- Nếu bạn cũng đang [vấn đề của khách], tôi hiểu bạn vì tôi từng ở đó:
- Lời mời bước tiếp theo (đọc blog, tải lead magnet, kết nối):

👉 Xem trang About đầy đủ trên blog: [dán link trang_about]
