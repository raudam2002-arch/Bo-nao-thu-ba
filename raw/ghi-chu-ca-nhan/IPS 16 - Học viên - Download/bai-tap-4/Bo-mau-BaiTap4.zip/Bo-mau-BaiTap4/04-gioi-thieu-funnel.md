---
loai: gioi-thieu-funnel
link_blog: ""
link_lead_page: ""
link_sale_page: ""
---

# Funnel của tôi

Đường đi của khách:

```
Bài viết / MXH  →  Lead Page (nhận Lead Magnet)  →  Email  →  Sale Page (mua Sản phẩm chính)
```

Giải thích từng bước + link tương ứng:

- Bước 1 — Thu hút:
- Bước 2 — Lead Page (link):
- Bước 3 — Nuôi dưỡng qua Email:
- Bước 4 — Sale Page (link):
