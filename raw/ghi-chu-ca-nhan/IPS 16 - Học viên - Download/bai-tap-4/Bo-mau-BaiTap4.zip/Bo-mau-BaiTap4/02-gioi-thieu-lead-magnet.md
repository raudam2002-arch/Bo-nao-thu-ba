---
loai: gioi-thieu-lead-magnet
ten_lead_magnet: ""
dinh_dang: ""   # ebook | checklist | video | mini-course | mẫu file
lead_page: ""
---

# Lead Magnet: [tên]

- Lead Magnet của tôi là gì:
- Giải quyết vấn đề gì cho khách:
- Vì sao khách muốn để lại email/SĐT để nhận:
- Link tải (Lead Page): [dán lead_page]
