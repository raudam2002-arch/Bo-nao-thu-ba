# Thư mục ẢNH — đọc trước khi bỏ ảnh vào

Bỏ ảnh vào đúng thư mục này. Đổi tên file cho đúng, xoá file README này khi nộp.

## Ảnh BẮT BUỘC (đổi tên đúng như dưới)
- [ ] `chan-dung.jpg`        — ảnh chân dung rõ mặt (avatar)
- [ ] `dang-lam-viec.jpg`    — ảnh đang làm việc
- [ ] `dang-hoc-tap.jpg`     — ảnh đang học tập
- [ ] `sinh-hoat.jpg`        — ảnh đời thường
- [ ] `gia-dinh.jpg`         — ảnh gia đình
- [ ] `lead-magnet-cover.jpg`
- [ ] `san-pham-chinh.jpg`
- [ ] `screenshot-blog.jpg`      — thấy URL trên thanh địa chỉ
- [ ] `screenshot-lead-page.jpg` — thấy URL
- [ ] `screenshot-sale-page.jpg` — thấy URL

## Gợi ý thêm (càng nhiều "người thật" càng tốt)
Ảnh với khách/học viên, ảnh sự kiện, ảnh hậu trường, ảnh sở thích cá nhân.

## Quy định kỹ thuật (BẮT BUỘC)
- Kích thước: cạnh dài nhất **1024–2048 px**
- Dung lượng: **mỗi file ≤ 2MB**
- Định dạng: `.jpg` (ưu tiên) hoặc `.png`
- Tên file: không dấu, không khoảng trắng, dùng gạch ngang `-`
