---
loai: checklist
ho_va_ten: ""
ngay_nop: "2026-__-__"
---

# CHECK LIST BÀI TẬP 4

## A. Cấu trúc & YAML
- [ ] Mọi file văn bản đều có khối YAML đầu file
- [ ] File 00 gộp thông tin học viên + giới thiệu bản thân
- [ ] Nén đúng cấu trúc thư mục .zip, tên file không dấu

## B. Blog & Giới thiệu bản thân (file 00)
- [ ] Blog + trang About lên sóng, truy cập được
- [ ] Bài About viết dạng câu chuyện, có link về trang About
- [ ] About có đủ: cuộc đời, gia đình, hành trình kinh doanh, các lĩnh vực khác
- [ ] YAML đủ 4 link sống: blog, trang_about, lead_page, sale_page

## C. Lead Magnet & Lead Page (file 02)
- [ ] Đã tạo Lead Magnet
- [ ] Đã dựng Lead Page, truy cập được
- [ ] Viết bài giới thiệu Lead Magnet

## D. Sản phẩm chính & Sale Page (file 03)
- [ ] Xác định Sản phẩm chính + giá
- [ ] Đã dựng Sale Page, truy cập được
- [ ] Viết bài giới thiệu Sản phẩm chính

## E. Funnel (file 04)
- [ ] Viết bài giới thiệu Funnel + sơ đồ
- [ ] Các link trong funnel nối thông nhau

## F. Bài viết lan toả (bai-viet-pr/)
- [ ] Viết sẵn ÍT NHẤT 5 bài
- [ ] Mỗi bài có đủ YAML: tu_khoa, tu_khoa_chinh, tu_khoa_lien_quan, tu_khoa_nguoi_mua_tim_kiem
- [ ] Mỗi bài có link back về MỘT BÀI BLOG CỤ THỂ (không phải trang chủ)
- [ ] Ghi rõ bài nào gửi cho ai (gui_cho)

## G. Ảnh (anh/)
- [ ] Đủ bộ: chân dung, đang làm việc, đang học tập, sinh hoạt, gia đình
- [ ] Có ảnh Lead Magnet, Sản phẩm chính
- [ ] Có screenshot Blog / Lead Page / Sale Page (thấy URL)
- [ ] Mọi ảnh: cạnh dài nhất 1024–2048px, dung lượng ≤ 2MB
