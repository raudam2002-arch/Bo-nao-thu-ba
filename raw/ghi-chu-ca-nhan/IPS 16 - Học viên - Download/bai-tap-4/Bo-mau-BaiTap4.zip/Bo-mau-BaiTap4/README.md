# BỘ MẪU BÀI TẬP 4 — điền vào rồi nộp

Đây là khung thư mục sẵn. Bạn chỉ việc **điền vào từng file** và **bỏ ảnh vào thư mục `anh/`**, sau đó nén lại thành `.zip` và nộp.

## Các bước
1. Mở từng file `.md`, điền vào phần YAML (trong dấu `---`) và nội dung. Xoá các dòng gợi ý (`<!-- ... -->`).
2. Bỏ ảnh vào `anh/` theo hướng dẫn trong `anh/README-doc-truoc-khi-bo-anh.md` (đúng kích thước 1024–2048px, ≤ 2MB).
3. Viết đủ **5 bài** trong `bai-viet-pr/` — nhớ điền 4 nhóm từ khoá + `link_back_bai_blog` (một bài blog cụ thể).
4. Tick lại `01-checklist.md`.
5. Đổi tên thư mục thành `HoTen-BaiTap4`, nén thành `HoTen-BaiTap4.zip`, upload qua **link nộp bài**: **https://forms.gle/3pX9WQpjYZFehp3VA**

## Danh sách file trong bộ mẫu
- `00-hoc-vien-va-gioi-thieu.md` — thông tin học viên + giới thiệu bản thân
- `01-checklist.md` — check list các việc đã làm
- `02-gioi-thieu-lead-magnet.md`
- `03-gioi-thieu-san-pham-chinh.md`
- `04-gioi-thieu-funnel.md`
- `bai-viet-pr/bai-01.md … bai-05.md` — 5 bài lan toả
- `anh/` — thư mục ảnh (đọc README bên trong)

> Xoá tất cả file README trước khi nộp.
